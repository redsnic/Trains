## Tutorial:

To execute the ASP solver run:

```
python2.7 ASPEncodingv3.py outputFilePath/OutputFileName < InputFilePath/InputFileName
```

OutputFileName should not contain any extension, the
program automatically adds .outASP to it. 


for the MiniZinc solver similarly execute:

```
python2.7 MinizincEncoding.py outputFilePath/OutputFileName < InputFilePath/InputFileName
```

to run both on all the files into a folder use:

```
./run.sh OUT_FOLDER IN_FOLDER
```

to run the complete benchmark suite use (this might take more than an hour):

```
./runALL.sh
```

> **NOTE**: This will rewrite the files in the `./testcases/ans/` folder.

to view informations about a test case or to see if one of yours is correctly formatted use:

```
./getInfo testcaseFile
```

