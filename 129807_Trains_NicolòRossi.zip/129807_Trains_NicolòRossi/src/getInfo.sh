python2.7 InputReader.py < $1
